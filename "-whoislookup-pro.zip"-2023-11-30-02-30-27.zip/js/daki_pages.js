/*
  Код написав Давид Манжула @da411d в 2020 році
  
  Це є моя власна заміна jPages.
  Вона пахає без jQuery і має менший функціонал.
  Чисто адаптована до того що нада в цій групі проєктів
  
  Одною з оптимізацій є оптимізація на стороні сервера. Вже там контент
  ділиться на сторінки і всім крім першої робиться display: none.
 */

(() => {

let styleInitialized = false;
const styles = `
.daki-pages-navbar {
  text-align: center;
}

.daki-pages-button {
  min-width: 100px;
  margin: 0 4px;
  padding: 8px 24px;
  background-color: rgba(0, 0, 0, 0.2);
  border-radius: 3px;
  cursor: pointer;
  border: none;
  color: inherit;
  font-size: 1em;
}

.daki-pages-button--number {
  pointer-events: none;
}

.daki-pages-button--disabled {
  pointer-events: none;
  opacity: 0.5;
}
`;

// Добавляєм методи стандартній колекції
HTMLCollection.prototype.forEach = Array.prototype.forEach;

// Обмежує число ліворуч і праворуч
const minmax = (number, min, max) => Math.max(min, Math.min(max, number));

/**
 * Функція мержить два об'єкта рекурсивно
 */
const mergeDeep = (target, source) => {
	if (target['@@merged']) {
		return target;
	}
	
	const isObject = item => (item && typeof item === 'object' && !Array.isArray(item));
	
	if (isObject(target) && isObject(source)) {
		for (const key in source) {
			if (isObject(source[key])) {
				if (!target[key]) Object.assign(target, { [key]: {} });
				mergeDeep(target[key], source[key]);
			} else {
				Object.assign(target, { [key]: source[key] });
			}
		}
	}
  target['@@merged'] = true;
	
	return target;
};

/**
 * Створює DOM елемент
 * @param tag ім'я тега
 * @param props атрибути елемента
 * @param children вкладені елементи
 * @returns {*}
 */
const el = (tag, props = {}, ...children) => {
	const el = document.createElement(tag);
  const events = props.on || {};
  
  // добавляєм пропси
	const elWithProps = mergeDeep(el, props);
  // добавляєм чайлдів
  children.forEach(child => elWithProps.appendChild(child));
  // добавляєм евенти
  for(const eventName in events){
    const callback = events[eventName].bind(elWithProps);
    elWithProps.addEventListener(eventName, callback);
  }
  
	return elWithProps;
};

/*
  Прості функції для роботи з DOM
 */
const hideElement = element => {
  if(element.style.display !== "none"){
    element.style.display = "none";
  }
};
const showElement = element => {
  if(element.style.display === "none"){
    element.style.display = "";
  }
};
  
/**
 * Створює стор, що управляє індексом
 * @param children
 * @returns {{broadcast: (function(*=): void), createUpdater: (function(*=): function(): undefined), subscribe: (function(*=): number), get: (function(): number), update: (function(*): (undefined))}}
 */
const createStore = children => {
  const callbacks = [];
  const subscribe = callback => callbacks.push(callback);
  const broadcast = message => callbacks.forEach(callback => callback(message));
  
  let index = 0;
  const get = () => index;
  const update = delta => {
    const newIndex = minmax(index + delta, 0, children.length - 1);
    if(index === newIndex){
      return;
    }
    
    broadcast({
      oldIndex: index,
      newIndex: newIndex,
    });
    index = newIndex;
  };
  const createUpdater = delta => () => update(delta);
  
  return {
    children,
    
    subscribe,
    broadcast,
    
    get,
    update,
    createUpdater,
  };
};

const createNavbar = ({ createUpdater, subscribe, children }) => {
  const prevButton = el("button", {
    innerText: "←",
    className: "daki-pages-button daki-pages-button--back daki-pages-button--disabled",
    on: {
      click: createUpdater(-1),
    }
  });
  const numberButton = el("button", {
    innerText: "1",
    className: "daki-pages-button daki-pages-button--number",
    on: {
      click: createUpdater(0),
    }
  });
  const nextButton = el("button", {
    innerText: "→",
    className: "daki-pages-button daki-pages-button--forward",
    on: {
      click: createUpdater(1),
    }
  });
  const paginationNavbar = el("div", {
    className: "daki-pages-navbar",
  }, prevButton, numberButton, nextButton);
  
  subscribe(({newIndex}) => {
    if(newIndex === 0){
      prevButton.classList.add("daki-pages-button--disabled");
    }else{
      prevButton.classList.remove("daki-pages-button--disabled");
    }
    
    numberButton.innerText = newIndex + 1;
    
    if(newIndex === children.length - 1){
      nextButton.classList.add("daki-pages-button--disabled");
    }else{
      nextButton.classList.remove("daki-pages-button--disabled");
    }
  });
  
  return paginationNavbar;
};

const createPagination = container => {
  if(container.classList.contains("daki-pages--initialized")){
    console.debug(container, "has been already initialized");
    return;
  }
  container.classList.add("daki-pages--initialized");
  
  const { children } = container;
  if(children.length <= 1){
    console.debug(container, "has not enough children");
    return;
  }
  
  const store = createStore(children);
  
  // Добавляєм навбар
  const paginationNavbar = createNavbar(store);
  container.insertAdjacentElement("afterend", paginationNavbar);
  
  // Підписуємся на зміни
  store.subscribe(({oldIndex, newIndex}) => {
    hideElement(children[oldIndex]);
    showElement(children[newIndex]);
  });
  // Скриваєм всі, потом відображаєм перший
  // children.forEach(hideElement);
  // showElement(children[store.get()]);
  
  // Установлюєм стилі
  if(!styleInitialized){
    const styleElement = el("style", {
      innerHTML: styles,
      className: "daki-pages-style",
    });
    document.head.appendChild(styleElement);
    styleInitialized = true;
  }
};

window._dakiPages = createPagination;

})();
