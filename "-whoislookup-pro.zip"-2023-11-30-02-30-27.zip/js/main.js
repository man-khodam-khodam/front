const $doc = $(document);
$(document).ready(function () {
  $('script:not(#script)').each(function (i, v) {
    let dataLoadSrc = $(v).data('load-src');
    let dataAdSrc = $(v).data('ad-src');

    if (dataLoadSrc !== '') {
      $(v).attr('src', dataLoadSrc)
    }

    if (dataAdSrc !== '') {
      $(v).attr('src', dataAdSrc)
    }
  });

  window.dataLayer = window.dataLayer || [];

  function gtag() {
    dataLayer.push(arguments);
  }

  gtag('js', new Date());

  gtag('config', 'G-4L057DYBQG');
  $('.adsbygoogle-defer').addClass('adsbygoogle');

  // let ppage = window.location.pathname.replace('/', '');
  // let isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  //
  // if (isMobile === true) {
  // 	$.ajax({
  // 		url: 'alternative_domain.php',
  // 		type: "POST",
  // 		data: {
  // 			ppage: ppage
  // 		}
  // 	}).done(function (data) {
  // 		$('#wbtn').css('pointer-events', 'none');
  // 		$('#wbtn h2').text('Domains Loading...');
  // 		setTimeout(function () {
  // 			$('#wbtn').css('pointer-events', 'auto');
  // 			$('#wbtn h2').text('Search whois domains with ' + ppage);
  // 			$(data).appendTo('#subwb #link-list4');
  // 		}, 5000);
  // 	})
  // }

  $doc.on('click', '.nav-tabs .nav-link', function (e) {
    e.preventDefault();
    let pageType = $(this).attr('href');
    let newUrl = window.location.href + pageType

    window.open(newUrl)
  });
})
var abc = ['.abogado', '.academy', '.accoun tants', '.actor', '.adult', '.agency', '.airforce', '.apartments', '.aquarelle', '.archi', '.army', '.associates', '.attorney', '.auction', '.audio', '.band', '.bank', '.bar', '.barclaycard', '.barclays', '.bargains', '.bayern', '.beer', '.best', '.bike', '.bingo', '.bio', '.biz', '.black', '.blackfriday', '.blue', '.bmw', '.boutique', '.brussels', '.builders', '.business', '.cab', '.camera', '.camp', '.cancerresearch', '.capetown', '.capital', '.cards', '.care', '.career', '.careers', '.casa', '.cash', '.casino', '.cat', '.catering', '.center', '.ceo', '.cern', '.chat', '.cheap', '.christmas', '.church', '.city', '.claims', '.cleaning', '.click', '.clinic', '.clothing', '.coach', '.codes', '.coffee', '.college', '.cologne', '.com', '.community', '.company', '.computer', '.condos', '.construction', '.consulting', '.contractors', '.cooking', '.cool', '.coop', '.country', '.courses', '.credit', '.creditcard', '.cricket', '.cruises', '.cymru', '.dance', '.dating', '.deals', '.degree', '.delivery', '.democrat', '.dental', '.dentist', '.desi', '.design', '.diamonds', '.diet', '.digital', '.direct', '.directory', '.discount', '.domains', '.durban', '.dvag', '.edu', '.education', '.email', '.energy', '.engineer', '.engineering', '.enterprises', '.equipment', '.estate', '.eus', '.events', '.exchange', '.expert', '.exposed', '.fail', '.fans', '.farm', '.fashion', '.feedback', '.finance', '.financial', '.firmdale', '.fish', '.fishing', '.fit', '.fitness', '.flights', '.florist', '.flowers', '.foo', '.football', '.forsale', '.foundation', '.frl', '.fund', '.furniture', '.futbol', '.gal', '.gallery', '.garden', '.gent', '.gift', '.gifts', '.gives', '.glass', '.globo', '.goog', '.google', '.gop', '.graphics', '.gratis', '.green', '.gripe', '.guide', '.guitars', '.guru', '.hamburg', '.haus', '.healthcare', '.help', '.hiphop', '.hiv', '.holdings', '.holiday', '.horse', '.hosting', '.house', '.how', '.immo', '.immobilien', '.industries', '.info', '.ink', '.institute', '.insure', '.international', '.investments', '.java', '.jcb', '.jobs', '.joburg', '.juegos', '.kaufen', '.kim', '.kitchen', '.koeln', '.krd', '.kyoto', '.land', '.lat', '.latrobe', '.lawyer', '.lease', '.leclerc', '.legal', '.lgbt', '.life', '.lighting', '.limited', '.limo', '.link', '.loans', '.london', '.ltda', '.luxury', '.maison', '.management', '.mango', '.market', '.marketing', '.media', '.melbourne', '.memorial', '.menu', '.miami', '.mini', '.mobi', '.moda', '.monash', '.money', '.mortgage', '.museum', '.navy', '.net', '.network', '.ngo', '.ninja', '.nra', '.nrw', '.one', '.ong', '.onl', '.ooo', '.org', '.organic', '.ovh', '.paris', '.partners', '.parts', '.photo', '.photography', '.photos', '.pics', '.pictures', '.pink', '.pizza', '.place', '.plumbing', '.poker', '.porn', '.productions', '.properties', '.property', '.pub', '.quebec', '.recipes', '.red', '.rehab', '.reise', '.reisen', '.reit', '.rentals', '.repair', '.report', '.republican', '.rest', '.restaurant', '.reviews', '.rich', '.rio', '.rip', '.rocks', '.rodeo', '.ru', '.ruhr', '.saarland', '.sale', '.sarl', '.saxo', '.school', '.schule', '.scot', '.services', '.sexy', '.shiksha', '.shoes', '.singles', '.social', '.software', '.solar', '.solutions', '.soy', '.study', '.style', '.su', '.supplies', '.supply', '.support', '.surf', '.surgery', '.sydney', '.systems', '.tattoo', '.tax', '.technology', '.tennis', '.tienda', '.tips', '.tires', '.tirol', '.today', '.tools', '.top', '.town', '.toys', '.training', '.trust', '.university', '.uol', '.us', '.vacations', '.vegas', '.ventures', '.versicherung', '.vet', '.viajes', '.video', '.villas', '.vision', '.vlaanderen', '.vodka', '.vote', '.voto', '.voyage', '.wales', '.wang', '.watch', '.wed', '.wedding', '.whoswho', '.wien', '.wiki', '.work', '.works', '.world', '.wtf', '.xn--1qqw23a', '.xn--3bst00m', '.xn--45q11c', '.xn--4gbrim', '.xn--55qx5d', '.xn--6frz82g', '.xn--6qq986b3xl', '.xn--80asehdb', '.xn--80aswg', '.xn--c1avg', '.xn--czrs0t', '.xn--czru2d', '.xn--fiq64b', '.xn--hxt814e', '.xn--i1b6b1a6a2e', '.xn--io0a7i', '.xn--kput3i', '.xn--ngbc5azd', '.xn--nqv7f', '.xn--p1acf', '.xn--q9jyb4c', '.xn--unup4y', '.xn--vhquv', '.xn--xhq521b', '.xxx', '.xyz', '.yoga', '.zone', '.ac', '.ad', '.ae', '.af', '.ag', '.am', '.as', '.at', '.au', '.aw', '.ax', '.be', '.bg', '.bi', '.bj', '.br', '.bw', '.by', '.bz', '.ca', '.cc', '.cd', '.cf', '.ch', '.ci', '.cl', '.cn', '.co', '.cx', '.cz', '.de', '.dk', '.dm', '.dz', '.ec', '.ee', '.es', '.eu', '.fi', '.fm', '.fo', '.fr', '.gd', '.gf', '.gg', '.gi', '.gl', '.gq', '.gr', '.gs', '.gy', '.hk', '.hn', '.hr', '.ht', '.hu', '.id', '.ie', '.il', '.im', '.in', '.io', '.iq', '.ir', '.is', '.it', '.je', '.jp', '.ke', '.kg', '.ki', '.kr', '.ky', '.kz', '.la', '.lc', '.li', '.lt', '.lu', '.lv', '.ly', '.ma', '.md', '.me', '.mg', '.mk', '.ml', '.mn', '.mo', '.ms', '.mu', '.mx', '.my', '.mz', '.na', '.nc', '.nf', '.ng', '.nl', '.no', '.nu', '.nz', '.om', '.pe', '.pf', '.ph', '.pl', '.pm', '.pr', '.pt', '.pw', '.qa', '.re', '.ro', '.rs', '.sa', '.sb', '.sc', '.se', '.sg', '.sh', '.si', '.sk', '.sm', '.sn', '.so', '.st', '.sx', '.sy', '.tc', '.tf', '.th', '.tj', '.tk', '.tl', '.tm', '.tn', '.to', '.tt', '.tv', '.tw', '.tz', '.ua', '.ug', '.uk', '.uy', '.uz', '.vc', '.ve', '.vg', '.vu', '.wf', '.ws', '.yt', '.zm'];

function whois(domain) {
  $('.raw_data').html('<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>');

  setTimeout(() => {
    $.post("/api_request.php", {domain: domain}, function (data) {
      result = JSON.parse(data);

      $('.raw_data').html('<pre>' + result.raw_whois + '</pre>');
    });
  }, 2500);
};
// $(".raw_data").html("Something went wrong. We can't process your request.")
var degs = 0;
$doc.on('click', '.box-domain a', function () {
  var loc = $(this).text();
  var locsort = loc.substring(loc.search('#'));
  $(".whoisinfo h2").text('Whois domain ' + locsort + '');
  degs = 360 + degs;
  $('.pb').css('transform', 'rotateY(' + degs + 'deg)');
  $('.pb div').toggleClass('zi');
  if (degs == 720) {
    degs = 0;
  }
  ;

  whois(locsort);
});

$doc.on('click', '.tab-content a', function () {
  var loc = $(this).text();
  var locc = $('#ppages').text();
  var loccc = locc.substring(locc.search(':'));
  var locf = loccc.slice(2) + locsort;
  var locsort = loc.substring(loc.search('#'));
  $('.slick-current div div').text(locf);
  $(".whoisinfo h2").text('Whois domain ' + locf + '');
  degs = 360 + degs;
  $('.pb').css('transform', 'rotateY(' + degs + 'deg)');
  $('.pb div').toggleClass('zi');
  if (degs == 720) {
    degs = 0;
  }
  ;

  whois(locf);
});

var zones = function () {
  if ($('#man').find('*').length == 0) {
    var a = ['com', 'net', 'org', 'uk', 'xyz', 'us', 'ru', 'se', 'eu', 'de', 'nl', 'cn', 'fr', 'biz', 'info'];
    var b = ['.abogado', '.academy', '.accountants', '.actor', '.adult', '.agency', '.airforce', '.apartments', '.aquarelle', '.archi', '.army', '.associates', '.attorney', '.auction', '.audio', '.band', '.bank', '.bar', '.barclaycard', '.barclays', '.bargains', '.bayern', '.beer', '.best', '.bike', '.bingo', '.bio', '.biz', '.black', '.blackfriday', '.blue', '.bmw', '.boutique', '.brussels', '.builders', '.business', '.cab', '.camera', '.camp', '.cancerresearch', '.capetown', '.capital', '.cards', '.care', '.career', '.careers', '.casa', '.cash', '.casino', '.cat', '.catering', '.center', '.ceo', '.cern', '.chat', '.cheap', '.christmas', '.church', '.city', '.claims', '.cleaning', '.click', '.clinic', '.clothing', '.coach', '.codes', '.coffee', '.college', '.cologne', '.com', '.community', '.company', '.computer', '.condos', '.construction', '.consulting', '.contractors', '.cooking', '.cool', '.coop', '.country', '.courses', '.credit', '.creditcard', '.cricket', '.cruises', '.cymru', '.dance', '.dating', '.deals', '.degree', '.delivery', '.democrat', '.dental', '.dentist', '.desi', '.design', '.diamonds', '.diet', '.digital', '.direct', '.directory', '.discount', '.domains', '.durban', '.dvag', '.edu', '.education', '.email', '.energy', '.engineer', '.engineering', '.enterprises', '.equipment', '.estate', '.eus', '.events', '.exchange', '.expert', '.exposed', '.fail', '.fans', '.farm', '.fashion', '.feedback', '.finance', '.financial', '.firmdale', '.fish', '.fishing', '.fit', '.fitness', '.flights', '.florist', '.flowers', '.foo', '.football', '.forsale', '.foundation', '.frl', '.fund', '.furniture', '.futbol', '.gal', '.gallery', '.garden', '.gent', '.gift', '.gifts', '.gives', '.glass', '.globo', '.goog', '.google', '.gop', '.graphics', '.gratis', '.green', '.gripe', '.guide', '.guitars', '.guru', '.hamburg', '.haus', '.healthcare', '.help', '.hiphop', '.hiv', '.holdings', '.holiday', '.horse', '.hosting', '.house', '.how', '.immo', '.immobilien', '.industries', '.info', '.ink', '.institute', '.insure', '.international', '.investments', '.java', '.jcb', '.jobs', '.joburg', '.juegos', '.kaufen', '.kim', '.kitchen', '.koeln', '.krd', '.kyoto', '.land', '.lat', '.latrobe', '.lawyer', '.lease', '.leclerc', '.legal', '.lgbt', '.life', '.lighting', '.limited', '.limo', '.link', '.loans', '.london', '.ltda', '.luxury', '.maison', '.management', '.mango', '.market', '.marketing', '.media', '.melbourne', '.memorial', '.menu', '.miami', '.mini', '.mobi', '.moda', '.monash', '.money', '.mortgage', '.museum', '.navy', '.net', '.network', '.ngo', '.ninja', '.nra', '.nrw', '.one', '.ong', '.onl', '.ooo', '.org', '.organic', '.ovh', '.paris', '.partners', '.parts', '.photo', '.photography', '.photos', '.pics', '.pictures', '.pink', '.pizza', '.place', '.plumbing', '.poker', '.porn', '.productions', '.properties', '.property', '.pub', '.quebec', '.recipes', '.red', '.rehab', '.reise', '.reisen', '.reit', '.rentals', '.repair', '.report', '.republican', '.rest', '.restaurant', '.reviews', '.rich', '.rio', '.rip', '.rocks', '.rodeo', '.ru', '.ruhr', '.saarland', '.sale', '.sarl', '.saxo', '.school', '.schule', '.scot', '.services', '.sexy', '.shiksha', '.shoes', '.singles', '.social', '.software', '.solar', '.solutions', '.soy', '.study', '.style', '.su', '.supplies', '.supply', '.support', '.surf', '.surgery', '.sydney', '.systems', '.tattoo', '.tax', '.technology', '.tennis', '.tienda', '.tips', '.tires', '.tirol', '.today', '.tools', '.top', '.town', '.toys', '.training', '.trust', '.university', '.uol', '.us', '.vacations', '.vegas', '.ventures', '.versicherung', '.vet', '.viajes', '.video', '.villas', '.vision', '.vlaanderen', '.vodka', '.vote', '.voto', '.voyage', '.wales', '.wang', '.watch', '.wed', '.wedding', '.whoswho', '.wien', '.wiki', '.work', '.works', '.world', '.wtf', '.xn--1qqw23a', '.xn--3bst00m', '.xn--45q11c', '.xn--4gbrim', '.xn--55qx5d', '.xn--6frz82g', '.xn--6qq986b3xl', '.xn--80asehdb', '.xn--80aswg', '.xn--c1avg', '.xn--czrs0t', '.xn--czru2d', '.xn--fiq64b', '.xn--hxt814e', '.xn--i1b6b1a6a2e', '.xn--io0a7i', '.xn--kput3i', '.xn--ngbc5azd', '.xn--nqv7f', '.xn--p1acf', '.xn--q9jyb4c', '.xn--unup4y', '.xn--vhquv', '.xn--xhq521b', '.xxx', '.xyz', '.yoga', '.zone'];
    var c = ['.ac', '.ad', '.ae', '.af', '.ag', '.am', '.as', '.at', '.au', '.aw', '.ax', '.be', '.bg', '.bi', '.bj', '.br', '.bw', '.by', '.bz', '.ca', '.cc', '.cd', '.cf', '.ch', '.ci', '.cl', '.cn', '.co', '.cx', '.cz', '.de', '.dk', '.dm', '.dz', '.ec', '.ee', '.es', '.eu', '.fi', '.fm', '.fo', '.fr', '.gd', '.gf', '.gg', '.gi', '.gl', '.gq', '.gr', '.gs', '.gy', '.hk', '.hn', '.hr', '.ht', '.hu', '.id', '.ie', '.il', '.im', '.in', '.io', '.iq', '.ir', '.is', '.it', '.je', '.jp', '.ke', '.kg', '.ki', '.kr', '.ky', '.kz', '.la', '.lc', '.li', '.lt', '.lu', '.lv', '.ly', '.ma', '.md', '.me', '.mg', '.mk', '.ml', '.mn', '.mo', '.ms', '.mu', '.mx', '.my', '.mz', '.na', '.nc', '.nf', '.ng', '.nl', '.no', '.nu', '.nz', '.om', '.pe', '.pf', '.ph', '.pl', '.pm', '.pr', '.pt', '.pw', '.qa', '.re', '.ro', '.rs', '.sa', '.sb', '.sc', '.se', '.sg', '.sh', '.si', '.sk', '.sm', '.sn', '.so', '.st', '.sx', '.sy', '.tc', '.tf', '.th', '.tj', '.tk', '.tl', '.tm', '.tn', '.to', '.tt', '.tv', '.tw', '.tz', '.ua', '.ug', '.uk', '.uy', '.uz', '.vc', '.ve', '.vg', '.vu', '.wf', '.ws', '.yt', '.zm'];
    a.forEach(function (value) {
      $("#man").append("<a>." + value + "</a> ");
    });
    b.forEach(function (value) {
      $("#menu1").append("<a>" + value + "</a> ");
    });
    c.forEach(function (value) {
      $("#menu2").append("<a>" + value + "</a> ");
    });
  }
  ;
};
