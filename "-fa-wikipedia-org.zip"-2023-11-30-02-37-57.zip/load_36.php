<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		half star
	</title><g fill="#36c"><path d="m5.4 12.5-1.6 7 6.2-3.7 6.2 3.7-1.6-7L20 7h-7L10 .5 7 7H0zm.8 3.7 1-4.3-3.7-3.4h4.6L10 4.6v9.3z"/></g></svg>
