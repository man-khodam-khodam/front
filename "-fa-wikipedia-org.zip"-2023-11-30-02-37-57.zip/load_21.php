<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		close
	</title><g fill="#36c"><path d="m4.3 2.9 12.8 12.8-1.4 1.4L2.9 4.3z"/><path d="M17.1 4.3 4.3 17.1l-1.4-1.4L15.7 2.9z"/></g></svg>
