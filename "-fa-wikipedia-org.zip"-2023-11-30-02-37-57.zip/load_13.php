<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		bullet list
	</title><g fill="#000"><path d="M1 15h12v2H1zm0-6h12v2H1zm0-6h12v2H1z"/><circle cx="17" cy="4" r="2"/><circle cx="17" cy="10" r="2"/><circle cx="17" cy="16" r="2"/></g></svg>
