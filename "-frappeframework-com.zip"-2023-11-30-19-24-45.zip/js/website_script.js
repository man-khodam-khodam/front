// website_script.js
function setup_version_switcher() {
	let version_switcher = $("nav").find(".nav-item.dropdown:contains('Version')");
	let version_regex = /\/v(\d+)\//i;
	function set_version_switcher_text(text) {
		setTimeout(() => {
		    version_switcher.find(".dropdown-toggle").toggleClass("active", text);
            version_switcher.toggle(Boolean(text));
		}, 100);
		version_switcher.find(".dropdown-toggle").text((text || "Version").trim());
	}

	function update_version_switcher() {
		let current_location = window.location.href;
		let url_version = current_location.match(version_regex);
		if (!url_version) {
			return set_version_switcher_text();
		}
		let version_text = null;
		version_switcher.find(".dropdown-item").each(function() {
			let link_text = $(this).text();
			let version_number_match = link_text.match(/(\d+)/);
			let version_matched = version_number_match && version_number_match[1] === url_version[1];
			if (version_matched) {
				version_text = link_text;
			}
			setTimeout(() => {
				$(this).toggleClass('active', version_matched)
			}, 50);
		})
		set_version_switcher_text(version_text)
	}
	update_version_switcher()
}

function hide_docs_link_in_docs_page() {
    let current_location = window.location.href;
    let is_doc_page = current_location.includes("/docs/");
    let docs_link = $("nav").find(".nav-item:contains('Docs')");
    docs_link.toggle(!Boolean(is_doc_page));
    
    // TODO: Remove this hack
    let new_version_link = $("nav").find(".nav-item:contains('Version 14')");
    new_version_link.toggle(!Boolean(is_doc_page));
}


$(document).ready(() => {
	setup_version_switcher();
	hide_docs_link_in_docs_page();
});




	if (navigator.doNotTrack != 1 && !window.is_404) {
		frappe.ready(() => {
			let browser = frappe.utils.get_browser();
			let query_params = frappe.utils.get_query_params();

			// Get visitor ID based on browser uniqueness
			import('https://openfpcdn.io/fingerprintjs/v3')
				.then(fingerprint_js => fingerprint_js.load())
				.then(fp => fp.get())
				.then(result => {
					frappe.call("frappe.website.doctype.web_page_view.web_page_view.make_view_log", {
						referrer: document.referrer,
						browser: browser.name,
						version: browser.version,
						user_tz: Intl.DateTimeFormat().resolvedOptions().timeZone,
						source: query_params.source,
						medium: query_params.medium,
						campaign: query_params.campaign,
						visitor_id: result.visitorId
					})
			})
		})
	}
